#include <iostream>
#include "libary.h"

int main() {
    return 0;
}