#include "debtor.h"
using namespace std;

Debtor::Debtor(string name, int id, int books, int book_id)
    : Person("", "", id, 0), name_debtor(name), books_debtor(books), id_book(book_id) {}

string Debtor::GetNameDebtor() const {
    return name_debtor;
}

int Debtor::GetBooksDebtor() const {
    return books_debtor;
}

int Debtor::GetIdBook() const {
    return id_book;
}

void Debtor::SetNameDebtor(const string& name) {
    name_debtor = name;
}

void Debtor::SetBooksDebtor(int books) {
    books_debtor = books;
}

void Debtor::SetIdBook(int book_id) {
    id_book = book_id;
}