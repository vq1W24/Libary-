#ifndef PERSON_H
#define PERSON_H

#include <string>
using namespace std;

class Person {
private:
    string first_name;
    string last_name;
    int person_id;
    int age;

public:
    Person(string first, string last, int id, int age);
    string GetFirstName() const;
    string GetLastName() const;
    int GetPersonId() const;
    int GetAge() const;
    void SetFirstName(const string& first);
    void SetLastName(const string& last);
    void SetPersonId(int id);
    void SetAge(int person_age);
};

#endif