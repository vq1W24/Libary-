#ifndef BOOK_H
#define BOOK_H
#include <string>
using namespace std;
class Book {
private:
    string book_name;
    string author_name;
    int book_id;
    int book_quantity;

public:
    Book(string name, string author, int id, int quantity);
    string GetBookName() const;
    string GetAuthorName() const;
    int GetBookId() const;
    int GetBookQuantity() const;
    void SetBookName(const string& name);
    void SetAuthorName(const string& author);
    void SetBookId(int id);
    void SetBookQuantity(int quantity);
};

#endif