#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "person.h"

class Employee : public Person {
private:
  std::string position;
  float salary;
  std::string schedule;

public:
  Employee(std::string first, std::string last, int id, int age,
           std::string position, float salary, std::string schedule);
  std::string GetPosition() const;
  float GetSalary() const;
  std::string GetSchedule() const;
  void SetPosition(const std::string &new_position);
  void SetSalary(float new_salary);
  void SetSchedule(const std::string &new_schedule);
};

#endif