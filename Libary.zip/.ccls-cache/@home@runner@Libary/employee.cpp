#include "employee.h"
using namespace std;

Employee::Employee(string first, string last, int id, int age, string position, float salary, string schedule)
    : Person(first, last, id, age), position(position), salary(salary), schedule(schedule) {}

string Employee::GetPosition() const {
    return position;
}

float Employee::GetSalary() const {
    return salary;
}

string Employee::GetSchedule() const {
    return schedule;
}

void Employee::SetPosition(const string& new_position) {
    position = new_position;
}

void Employee::SetSalary(float new_salary) {
    salary = new_salary;
}

void Employee::SetSchedule(const string& new_schedule) {
    schedule = new_schedule;
}