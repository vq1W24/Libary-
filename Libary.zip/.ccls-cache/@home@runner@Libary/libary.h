#ifndef LIBRARY_H
#define LIBRARY_H
using namespace std;

#include <vector>
#include "book.h"
#include "employee.h"
#include "debtor.h"

class Library {
private:
    vector<Book> books;
    vector<Employee> employees;
    vector<Debtor> debtors;

public:
};

#endif