#ifndef DEBTOR_H
#define DEBTOR_H

#include "person.h"
using namespace std;

class Debtor : public Person {
private:
    string name_debtor;
    int books_debtor;
    int id_book;

public:
    Debtor(string name, int id, int books, int book_id);
    string GetNameDebtor() const;
    int GetBooksDebtor() const;
    int GetIdBook() const;
    void SetNameDebtor(const string& name);
    void SetBooksDebtor(int books);
    void SetIdBook(int book_id);
};

#endif