#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
private:
  std::string first_name;
  std::string last_name;
  int person_id;
  int age;

public:
  Person(std::string first, std::string last, int id, int age);
  std::string GetFirstName() const;
  std::string GetLastName() const;
  int GetPersonId() const;
  int GetAge() const;
  void SetFirstName(const std::string &first);
  void SetLastName(const std::string &last);
  void SetPersonId(int id);
  void SetAge(int person_age);
};

#endif