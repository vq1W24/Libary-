#include "person.h"
using namespace std;

Person::Person(string first, string last, int id, int age)
    : first_name(first), last_name(last), person_id(id), age(age) {}

string Person::GetFirstName() const {
    return first_name;
}

string Person::GetLastName() const {
    return last_name;
}

int Person::GetPersonId() const {
    return person_id;
}

int Person::GetAge() const {
    return age;
}

void Person::SetFirstName(const string& first) {
    first_name = first;
}

void Person::SetLastName(const string& last) {
    last_name = last;
}

void Person::SetPersonId(int id) {
    person_id = id;
}

void Person::SetAge(int person_age) {
    age = person_age;
}