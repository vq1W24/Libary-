#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "person.h"
using namespace std;

class Employee : public Person {
private:
  string position;
  float salary;
  string schedule;

public:
  Employee(string first, string last, int id, int age,
           string position, float salary, string schedule);
  string GetPosition() const;
  float GetSalary() const;
  string GetSchedule() const;
  void SetPosition(const string &new_position);
  void SetSalary(float new_salary);
  void SetSchedule(const string &new_schedule);
};

#endif