#include "book.h"
using namespace std;

Book::Book(string name, string author, int id, int quantity)
    : book_name(name), author_name(author), book_id(id), book_quantity(quantity) {}

string Book::GetBookName() const {
    return book_name;
}

string Book::GetAuthorName() const {
    return author_name;
}

int Book::GetBookId() const {
    return book_id;
}

int Book::GetBookQuantity() const {
    return book_quantity;
}

void Book::SetBookName(const string& name) {
    book_name = name;
}

void Book::SetAuthorName(const string& author) {
    author_name = author;
}

void Book::SetBookId(int id) {
    book_id = id;
}

void Book::SetBookQuantity(int quantity) {
    book_quantity = quantity;
}